package networkslabs2;
/*
 * TextReceiver.java
 *
 * Created on 15 January 2003, 15:43
 */

/**
 *
 * @author abj
 */
import CMPC3M06.AudioPlayer;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import uk.ac.uea.cmp.voip.*;

public class TextReceiverThread implements Runnable {

    static DatagramSocket2 receiving_socket;
    public final int D=3;
    public int Dlength = D*D;
    public void start() {
        Thread thread = new Thread(this);
        thread.start();
    }

    public void run() {

        try {
            
            //***************************************************
            //Port to open socket on
            int PORT = 55555;
            //***************************************************
            
            //***************************************************
            //Open a socket to receive from on port PORT
            //DatagramSocket receiving_socket;
            try {
                receiving_socket = new DatagramSocket2(PORT);
                
                
                
                
            } catch (SocketException e) {
                System.out.println("ERROR: TextReceiver: Could not open UDP socket to receive from.");
                e.printStackTrace();
                System.exit(0);
            }
            //***************************************************

            //***************************************************
            //Main loop.
            boolean running = true;
            AudioPlayer player = new AudioPlayer();
            
            while (running) {
                
                try {
                    ArrayList<PacketClass> gottenPacketClasses = new ArrayList<>();
                    ArrayList<PacketClass> orderedpackets = new ArrayList<>();
                    //Receive a DatagramPacket (note that the string cant be more than 80 chars)
                    byte[] buffer = new byte[516];
                    int recievingID;
                    ByteBuffer bbf; 
                    
                    for (int i = 0; i < Dlength; i++) 
                    {
                        bbf = ByteBuffer.allocate(516);
                        DatagramPacket packet = new DatagramPacket(bbf.array(), 0, 516);
                        receiving_socket.receive(packet);
                        
                        PacketClass p = new PacketClass();
                        p.decode(bbf);
                        gottenPacketClasses.add(p);
                        
                    }
                    orderedpackets = reorderPackets(gottenPacketClasses);
                    
                    int filled = fillmissing(orderedpackets);
                    
                    for (int p = 0; p < orderedpackets.size(); p++) 
                    {
                        buffer = gottenPacketClasses.get(p).getBlock();
                        recievingID = gottenPacketClasses.get(p).getID();
                        System.out.println("RECIEVED PACKET: " + recievingID);
                        player.playBlock(buffer);
                    }
                    System.out.println("repeating packets: "+filled+" per "+Dlength+" packets");
                    
                    
//                //Get a string from the byte buffer
//                String str = new String(buffer);
//                //Display it
//                if(!(str.isEmpty() || str.trim().isEmpty() || str.equals("")))
//                {
//                   System.out.println("Recieved: "+str); 
//                }
//
//
//                //The user can type EXIT to quit
//                if (str.substring(0,4).equals("EXIT")){
//                     running=false;
//                }
                } catch (IOException e) {
                    System.out.println("ERROR: TextReceiver: Some random IO error occured!");
                    e.printStackTrace();
                }
            }
            //Close the socket
            receiving_socket.close();
            //***************************************************
        } catch (LineUnavailableException ex) {
            Logger.getLogger(TextReceiverThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        //***************************************************
    }

    public ArrayList<PacketClass> reorderPackets(ArrayList<PacketClass> gottenPacketClasses) 
    {
        Collections.sort(gottenPacketClasses);
        
        
        return gottenPacketClasses;
    }

    private int fillmissing(ArrayList<PacketClass> orderedpackets) 
    {
        int missed = 0;
        for (int i=0; i<orderedpackets.size()-1; i++){
            if(orderedpackets.get(i+1).getID() != orderedpackets.get(i).getID()+1)
            {
                orderedpackets.add(i+1, orderedpackets.get(i));
                i++;
                missed++;
            }
        }   
        return missed;
    }
}
