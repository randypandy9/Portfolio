package networkslabs2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;


/*
 * TextDuplex.java
 *
 * Created on 15 January 2003, 17:11
 */
/**
 *
 * @author abj
 */
public class TextDuplex {

    public static void main(String[] args) {

//        int D = 3;
//        ArrayList<Integer> arr = new ArrayList<>();
//
//        arr.add(2);
//        arr.add(5);
//        arr.add(8);
//        arr.add(1);
//        arr.add(4);
//        arr.add(7);
//        arr.add(0);
//        arr.add(0);
//        arr.add(0);
//        ArrayList<Integer> arer = new ArrayList<>();
////
////        for (int x = 0; x < D; x++) {
////            
////            for (int y = 0; y < D; y++) {
////                
////                int chosen = (x * D) + y;
////                
////                System.out.println("--" + chosen);
////                
////                if (arr.contains(chosen)) {
////                    arer.add(chosen);
////                }
////            }
////        }
////        
//        Collections.sort(arr);
//        System.out.println(arr.toString());
//        for (int a = 0; a < arer.size(); a++) {
//            System.out.println(arer.get(a));
//        }

        TextReceiverThread receiver = new TextReceiverThread();
        TextSenderThread sender = new TextSenderThread();
        
        receiver.start();
        sender.start();
    }

}
