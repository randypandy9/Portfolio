package networkslabs;
/*
 * TextReceiver.java
 *
 * Created on 15 January 2003, 15:43
 */

/**
 *
 * @author abj
 */
import CMPC3M06.AudioPlayer;
import java.io.*;
import java.net.*;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.LineUnavailableException;
import uk.ac.uea.cmp.voip.*;

public class TextReceiverThread implements Runnable {

    static DatagramSocket receiving_socket;

    public void start() {
        Thread thread = new Thread(this);
        thread.start();
    }

    public void run() {

        try {
            
            //***************************************************
            //Port to open socket on
            int PORT = 55555;
            //***************************************************
            
            //***************************************************
            //Open a socket to receive from on port PORT
            //DatagramSocket receiving_socket;
            try {
                receiving_socket = new DatagramSocket(PORT);
            } catch (SocketException e) {
                System.out.println("ERROR: TextReceiver: Could not open UDP socket to receive from.");
                e.printStackTrace();
                System.exit(0);
            }
            //***************************************************

            //***************************************************
            //Main loop.
            boolean running = true;
            AudioPlayer player = new AudioPlayer();
            
            while (running) {
                
                try {
                    
                    //Receive a DatagramPacket (note that the string cant be more than 80 chars)
                    byte[] buffer = new byte[512];
                    
                    DatagramPacket packet = new DatagramPacket(buffer, 0, 512);
                    
                    receiving_socket.receive(packet);
                    
                    
                    
                    player.playBlock(buffer);
                    
//                //Get a string from the byte buffer
//                String str = new String(buffer);
//                //Display it
//                if(!(str.isEmpty() || str.trim().isEmpty() || str.equals("")))
//                {
//                   System.out.println("Recieved: "+str); 
//                }
//
//
//                //The user can type EXIT to quit
//                if (str.substring(0,4).equals("EXIT")){
//                     running=false;
//                }
                } catch (IOException e) {
                    System.out.println("ERROR: TextReceiver: Some random IO error occured!");
                    e.printStackTrace();
                }
            }
            //Close the socket
            receiving_socket.close();
            //***************************************************
        } catch (LineUnavailableException ex) {
            Logger.getLogger(TextReceiverThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        //***************************************************
    }
}
