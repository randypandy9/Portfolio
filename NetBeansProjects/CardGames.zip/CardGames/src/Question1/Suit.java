package Question1;

/**
 *
 * @author ysj13kxu
 */
//All the suits
public enum Suit {

    clubs, diamonds, hearts, spades
};
